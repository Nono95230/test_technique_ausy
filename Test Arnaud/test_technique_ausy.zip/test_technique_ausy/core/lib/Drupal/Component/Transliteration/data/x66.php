<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yun', 'bei', 'ang', 'ze', 'ban', 'jie', 'kun', 'sheng', 'hu', 'fang', 'hao', 'gui', 'chang', 'xuan', 'ming', 'hun',
  0x10 => 'fen', 'qin', 'hu', 'yi', 'xi', 'xin', 'yan', 'ze', 'fang', 'tan', 'shen', 'ju', 'yang', 'zan', 'bing', 'xing',
  0x20 => 'ying', 'xuan', 'po', 'zhen', 'ling', 'chun', 'hao', 'mei', 'zuo', 'mo', 'bian', 'xu', 'hun', 'zhao', 'zong', 'shi',
  0x30 => 'shi', 'yu', 'fei', 'die', 'mao', 'ni', 'chang', 'wen', 'dong', 'ai', 'bing', 'ang', 'zhou', 'long', 'xian', 'kuang',
  0x40 => 'tiao', 'chao', 'shi', 'huang', 'huang', 'xuan', 'kui', 'xu', 'jiao', 'jin', 'zhi', 'jin', 'shang', 'tong', 'hong', 'yan',
  0x50 => 'gai', 'xiang', 'shai', 'xiao', 'ye', 'yun', 'hui', 'han', 'han', 'jun', 'wan', 'xian', 'kun', 'zhou', 'xi', 'cheng',
  0x60 => 'sheng', 'bu', 'zhe', 'zhe', 'wu', 'han', 'hui', 'hao', 'chen', 'wan', 'tian', 'zhuo', 'zui', 'zhou', 'pu', 'jing',
  0x70 => 'xi', 'shan', 'ni', 'xi', 'qing', 'qi', 'jing', 'gui', 'zheng', 'yi', 'zhi', 'an', 'wan', 'lin', 'liang', 'chang',
  0x80 => 'wang', 'xiao', 'zan', 'fei', 'xuan', 'geng', 'yi', 'xia', 'yun', 'hui', 'xu', 'min', 'kui', 'ye', 'ying', 'shu',
  0x90 => 'wei', 'shu', 'qing', 'mao', 'nan', 'jian', 'nuan', 'an', 'yang', 'chun', 'yao', 'suo', 'jin', 'ming', 'jiao', 'kai',
  0xA0 => 'gao', 'weng', 'chang', 'qi', 'hao', 'yan', 'li', 'ai', 'ji', 'ji', 'men', 'zan', 'xie', 'hao', 'mu', 'mo',
  0xB0 => 'cong', 'ni', 'zhang', 'hui', 'bao', 'han', 'xuan', 'chuan', 'liao', 'xian', 'dan', 'jing', 'pie', 'lin', 'tun', 'xi',
  0xC0 => 'yi', 'ji', 'huang', 'dai', 'ye', 'ye', 'li', 'tan', 'tong', 'xiao', 'fei', 'shen', 'zhao', 'hao', 'yi', 'xiang',
  0xD0 => 'xing', 'shen', 'jiao', 'bao', 'jing', 'yan', 'ai', 'ye', 'ru', 'shu', 'meng', 'xun', 'yao', 'pu', 'li', 'chen',
  0xE0 => 'kuang', 'die', 'liao', 'yan', 'huo', 'lu', 'xi', 'rong', 'long', 'nang', 'luo', 'luan', 'shai', 'tang', 'yan', 'zhu',
  0xF0 => 'yue', 'yue', 'qu', 'ye', 'geng', 'ye', 'hu', 'he', 'shu', 'cao', 'cao', 'sheng', 'man', 'ceng', 'ceng', 'ti',
];
